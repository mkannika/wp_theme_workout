$(document).ready(function(){

	// if($('.match-height').lenght){
	// 	$('.match-height').matchHeight();
	// }

	// $(window).on('load', function(){

	// 	$('.match-height').matchHeight();
		
	// });

	$('#toggle-menu').click(function(){
		$('.site-header').toggleClass('open');
	});
});